# Rayeva assignment — folder contents

- `Rayeva_Assignment.docx` — website audit, AI feature proposal, and ESG workflow design (with diagram + stage table)
- `demo/index.html` — clickable interactive demo of the ESG workflow (this is what you deploy for the "demo link" deliverable)

## How to deploy the demo (pick one, all free)

### Option A — Netlify (easiest, no account setup needed first)
1. Go to https://app.netlify.com/drop
2. Drag the `demo` folder into the browser window
3. Netlify gives you a live URL instantly (e.g. `random-name-123.netlify.app`)
4. Copy that link and paste it into the assignment submission

### Option B — GitHub Pages
1. Create a new GitHub repo (e.g. `rayeva-assignment-demo`)
2. Upload `demo/index.html` to the repo (rename nothing — keep it as `index.html`)
3. Go to repo **Settings → Pages**
4. Under "Source", select the `main` branch and `/ (root)` folder → Save
5. Your live link will be `https://<your-username>.github.io/rayeva-assignment-demo/`

### Option C — Vercel
1. Go to https://vercel.com/new
2. Import the folder or drag-and-drop `demo/`
3. Deploy — Vercel gives you a live URL

## After deploying
Open `Rayeva_Assignment.docx`, find the "Deployed demo" section at the end, and replace the placeholder text with your actual live URL before submitting on Internshala.
